﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace BankOperations
{
    public partial class NewUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
                Panel1.Visible = false;
            
        }
        //code to check wheather user with account number exist or not
        protected void Button1_Click(object sender, EventArgs e)
        {
            int n;
            n = Convert.ToInt16(TextBox1.Text);
           
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;

            scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
            scon.Open();
            scmd = new SqlCommand("select unm from users where acc_no=@a;", scon);
            scmd.Parameters.AddWithValue("a", n);

            sda = new SqlDataAdapter(scmd);
            ds = new DataSet();
            sda.Fill(ds, "acc");

            int m = ds.Tables["acc"].Rows.Count;
            if (m > 0)
            {
                lblnot.Text = "";
                Panel1.Visible = true;
                txtName.Text = Convert.ToString(ds.Tables["acc"].Rows[0][0]);
                
                

            }
            else
            {
                Panel1.Visible = false;
                lblnot.Text="Record Not Found";
               
            }
        }
        //Code to register new customer after getting account number
        
        protected void btnregister_Click1(object sender, EventArgs e)
        {
            String  pass,nm,gn,mob,email,adds,cty,squs,ans;
            DateTime dob;
            int no;
            if (rbmale.Checked)
                gn = "male";
            else
                gn = "female";
            no = Convert.ToInt16(TextBox1.Text);
            nm = txtName.Text;
            dob = Convert.ToDateTime(txtdob.Text);
            mob = txtmob.Text;
            email = txtemail.Text;
            adds = txtaddress.Text;
            cty = txtcity.Text;
            squs = ddlqus.SelectedItem.Value;
            ans = txtans.Text;
            pass = txtpass.Text;
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();
                scmd = new SqlCommand("update users set psw=@a where acc_no=@b;", scon);
                scmd.Parameters.AddWithValue("a", pass);
                scmd.Parameters.AddWithValue("b", no);
                scmd.ExecuteNonQuery();
                
                scmd = new SqlCommand("insert into user_personal values(@a,@b,@c,@d,@e,@f,@g,@h,@i,@j);", scon);
                scmd.Parameters.AddWithValue("a", no);
                scmd.Parameters.AddWithValue("b", nm);
                scmd.Parameters.AddWithValue("c", dob);
                scmd.Parameters.AddWithValue("d", mob);
                scmd.Parameters.AddWithValue("e", email);
                scmd.Parameters.AddWithValue("f", adds);
                scmd.Parameters.AddWithValue("g", cty);
                scmd.Parameters.AddWithValue("h", squs);
                scmd.Parameters.AddWithValue("i", ans);
                scmd.Parameters.AddWithValue("j", gn);
                scmd.ExecuteNonQuery();
                lblmsg.Text = "Information Updated Successfully.....!";
                scon.Close();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //code to pick date
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Calendar1.Visible = true;
            Panel1.Visible = true;
        }
        //code for calender
        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            txtdob.Text = Calendar1.SelectedDate.ToLongDateString();
            Panel1.Visible = true;

            Calendar1.Visible = false;
        }
    }
}