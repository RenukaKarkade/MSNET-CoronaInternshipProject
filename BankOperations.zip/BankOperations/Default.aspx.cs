﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace BankOperations
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e) //Code for login
        {
            String id, psw, ddl;
            id = txtUserName.Text;
            psw = txtPassword.Text;
            ddl = ddlUserType.SelectedItem.Value;
            SqlDataAdapter sda;
            DataSet ds;
            SqlConnection scon;
            SqlCommand scmd;
            try
            {
                
                if (ddl == "Manager")
                {
                    scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                    scmd = new SqlCommand("select * from employees where eid=@a and psw=@b and etype='Manager';", scon);
                    scon.Open();
                    scmd.Parameters.AddWithValue("a", id);
                    scmd.Parameters.AddWithValue("b", psw);
                    sda = new SqlDataAdapter(scmd);
                    ds = new DataSet();
                    sda.Fill(ds, "us");

                    if (ds.Tables["us"].Rows.Count > 0)
                    {
                        Session["userid"] = id;
                        Response.Redirect("Manager.aspx");
                    }
                    else
                        Label1.Text = "Sorry password incorrect";
                   
                }
                else if (ddl == "Cashier")
                {
                    scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                    scmd = new SqlCommand("select * from employees where eid=@a and psw=@b and etype='Cashier';", scon);
                    scon.Open();
                    scmd.Parameters.AddWithValue("a", id);
                    scmd.Parameters.AddWithValue("b", psw);
                    sda = new SqlDataAdapter(scmd);
                    ds = new DataSet();
                    sda.Fill(ds, "us");

                    if (ds.Tables["us"].Rows.Count > 0)
                    {
                        Session["userid"] = id;
                        Response.Redirect("Cashier.aspx");
                    }
                    else
                        Label1.Text = "Sorry password incorrect";
                }

                else
                {
                    scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                    scmd = new SqlCommand("select * from users where acc_no=@a and psw=@b and ustatus='Active' and acc_status='Open';", scon);
                    scon.Open();
                    scmd.Parameters.AddWithValue("a", id);
                    scmd.Parameters.AddWithValue("b", psw);
                    sda = new SqlDataAdapter(scmd);
                    ds = new DataSet();
                    sda.Fill(ds, "us");

                    if (ds.Tables["us"].Rows.Count > 0)
                    {
                        Session["userid"] = id;
                        Response.Redirect("Customer.aspx");
                    }
                    else
                        Label1.Text = "Sorry password incorrect";

                }

                           }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


        }

        
    }
}