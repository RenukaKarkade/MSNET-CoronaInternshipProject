﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace BankOperations
{
    public partial class Cashier : System.Web.UI.Page
    {
        String uid = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            
            uid = Convert.ToString(Session["userid"]);
            if (uid != "na")
                Label1.Text = "Logged in as:" + uid;
            else
                Label1.Text = "Invalid Session....Please Login...!";


        }

        protected void Tab1_Click(object sender, EventArgs e) //tab Search Account
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Clicked";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Initial";
                MainView.ActiveViewIndex = 0;
            }
        }

        protected void Tab2_Click(object sender, EventArgs e) // tab Deposit
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Clicked";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Initial";
                MainView.ActiveViewIndex = 1;
            }
        }

        protected void Tab3_Click(object sender, EventArgs e) // tab Withdraw
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Clicked";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Initial";
                MainView.ActiveViewIndex = 2;
            }
        }

        protected void Tab4_Click(object sender, EventArgs e) //tab Transfer Amount 
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Clicked";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Initial";
                MainView.ActiveViewIndex = 3;
            }
        }

        protected void Tab5_Click(object sender, EventArgs e) //tab Daily Transaction report
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Clicked";
                Tab6.CssClass = "Initial";
                MainView.ActiveViewIndex = 4;
            }
        }

        protected void Tab6_Click(object sender, EventArgs e)//tab Logout
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Clicked";
                MainView.ActiveViewIndex = 5;
                Session.Abandon();
                Response.Redirect("Default.aspx");
            }
        }

        protected void btnsubmit_Click(object sender, EventArgs e) //code for tab Search Accouunt
        {
            SqlConnection scon;
            SqlDataAdapter sda;
            SqlCommand scmd;
            DataSet ds;

            scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
            scmd = new SqlCommand("select * from accounts where acc_no=@a;", scon);
            scmd.Parameters.AddWithValue("a", stxtaccno.Text);
            sda = new SqlDataAdapter(scmd);
            ds = new DataSet();
            sda.Fill(ds, "acc");
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
        
        //textbox code for close account to check wheather account is open or closed
        protected void dtxtacc_no_TextChanged(object sender, EventArgs e)
        {
            int acc;
            lbldepomsg.Text = "";
            acc = Convert.ToInt16(dtxtacc_no.Text);
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("SELECT ustatus,acc_status FROM accounts where acc_no=@b; ", scon);
                scmd.Parameters.AddWithValue("b", acc);

                sda = new SqlDataAdapter(scmd);
                ds = new DataSet();
                sda.Fill(ds, "acc");

                int m = ds.Tables["acc"].Rows.Count;
                if (m > 0)
                {
                    String ustatus = Convert.ToString(ds.Tables["acc"].Rows[0]["ustatus"]);
                    String accstatus = Convert.ToString(ds.Tables["acc"].Rows[0]["acc_status"]);
                    if (ustatus == "Active" & accstatus == "Open")
                    {

                    }
                    else
                    {
                        lbldepomsg.Text = "Account Closed or User Deactivated";
                        dtxtacc_no.Text = "";
                        dtxtacc_no.Enabled = false;
                        dtxtamt.Enabled = false;
                        return;

                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        
        //reset code for deposit tab
        protected void btndeporeset_Click(object sender, EventArgs e)
        {
            lbldepomsg.Text = "";
            dtxtacc_no.Enabled = true;
            dtxtamt.Enabled = true;
            dtxtacc_no.Text = "";
            dtxtamt.Text = "";
            Label2.Text = "";
        }
       
        //code for tab Deposit
        protected void btnDsub_Click(object sender, EventArgs e)
        {
            int acc;
            String trans_ty;
            double amt;
            DateTime dt = DateTime.Today;

            hdndepodate.Value = String.Format("{0:yyyy-MM-dd}", dt);
            acc = Convert.ToInt16(dtxtacc_no.Text);
            trans_ty = dtxttranstyp.Text;
            amt = Convert.ToDouble(dtxtamt.Text);
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("insert into trans_info(to_acc_no,amount,trans_type,date) values(@a,@b,@c,@d);", scon);
                scmd.Parameters.AddWithValue("a", acc);
                scmd.Parameters.AddWithValue("b", amt);
                scmd.Parameters.AddWithValue("c", trans_ty);
                scmd.Parameters.AddWithValue("d", hdndepodate.Value);
                scmd.ExecuteNonQuery();

                scmd = new SqlCommand("update accounts set balance=balance + @a where acc_no=@b;", scon);
                scmd.Parameters.AddWithValue("a", amt);
                scmd.Parameters.AddWithValue("b", acc);
                scmd.ExecuteNonQuery();
                Label2.Text = "Amount Deposited Successfully....!";
                scon.Close();
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
       
        //textbox code for Withdraw account to check wheather account is open or closed
        protected void wtxtaccno_TextChanged(object sender, EventArgs e)
        {
            int acc;
            lblwithmsg.Text = "";
            acc = Convert.ToInt16(wtxtaccno.Text);
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("SELECT ustatus,acc_status FROM accounts where acc_no=@b; ", scon);
                scmd.Parameters.AddWithValue("b", acc);

                sda = new SqlDataAdapter(scmd);
                ds = new DataSet();
                sda.Fill(ds, "acc");

                int m = ds.Tables["acc"].Rows.Count;
                if (m > 0)
                {
                    String ustatus = Convert.ToString(ds.Tables["acc"].Rows[0]["ustatus"]);
                    String accstatus = Convert.ToString(ds.Tables["acc"].Rows[0]["acc_status"]);
                    if (ustatus == "Active" & accstatus == "Open")
                    {

                    }
                    else
                    {
                        lblwithmsg.Text = "Account Closed or User Deactivated";
                        wtxtaccno.Text = "";
                        wtxtaccno.Enabled = false;
                        wtxtamt.Enabled = false;
                        return;

                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        
        //reset code for Withdraw tab
        protected void btnwithreset_Click(object sender, EventArgs e)
        {
            lblwithmsg.Text = "";
            wtxtaccno.Enabled = true;
            wtxtamt.Enabled = true;
            wtxtaccno.Text= "";
            wtxtamt.Text = "";
            Label4.Text = "";
        }
        
        //code for tab Withdraw
        protected void btnwsub_Click(object sender, EventArgs e)
        {
            int acc;
            String trans_ty;
            double amt;
            DateTime dt = DateTime.Today;
            hdnwithdt.Value = String.Format("{0:yyyy-MM-dd}", dt);

            acc = Convert.ToInt16(wtxtaccno.Text);
            trans_ty = wtxtwith.Text;
            amt = Convert.ToDouble(wtxtamt.Text);
            SqlConnection scon;
            SqlCommand scmd;
            
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("insert into trans_info(frm_acc_no,amount,trans_type,date) values(@a,@b,@c,@d);", scon);
                scmd.Parameters.AddWithValue("a", acc);
                scmd.Parameters.AddWithValue("b", amt);
                scmd.Parameters.AddWithValue("c", trans_ty);
                scmd.Parameters.AddWithValue("d", hdnwithdt.Value);
                scmd.ExecuteNonQuery();

                scmd = new SqlCommand("update accounts set balance=balance - @a where acc_no=@b;", scon);
                scmd.Parameters.AddWithValue("a", amt);
                scmd.Parameters.AddWithValue("b", acc);
                scmd.ExecuteNonQuery();
                scon.Close();
                Label4.Text = "Amount Withdraw....!";

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        
        //textbox code for to check wheather account is open or closed
        protected void ttxttoacc_TextChanged(object sender, EventArgs e)
        {
            int toacc;
            toacc = Convert.ToInt16(ttxttoacc.Text);
            lbltoaccmsg.Text = "";
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("SELECT ustatus,acc_status FROM accounts where acc_no=@a; ", scon);
                scmd.Parameters.AddWithValue("a", toacc);

                sda = new SqlDataAdapter(scmd);
                ds = new DataSet();
                sda.Fill(ds, "acc");

                int m = ds.Tables["acc"].Rows.Count;
                if (m > 0)
                {
                    String ustatus = Convert.ToString(ds.Tables["acc"].Rows[0]["ustatus"]);
                    String accstatus = Convert.ToString(ds.Tables["acc"].Rows[0]["acc_status"]);
                    if (ustatus == "Active" & accstatus == "Open")
                    {

                    }
                    else
                    {
                        lbltoaccmsg.Text = "Account Closed or User Deactivated";
                        ttxttoacc.Text = "";
                        ttxttoacc.Enabled = false;
                        ttxtfrmacc.Enabled = false;
                        ttxtamt.Enabled = false;
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        
        //textbox code for  to check wheather account is open or closed
        protected void ttxtfrmacc_TextChanged(object sender, EventArgs e)
        {
            int frmacc;
            frmacc = Convert.ToInt16(ttxtfrmacc.Text);
            lblfrmaccmsg.Text = "";
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("SELECT ustatus,acc_status FROM accounts where acc_no=@a; ", scon);
                scmd.Parameters.AddWithValue("a", frmacc);

                sda = new SqlDataAdapter(scmd);
                ds = new DataSet();
                sda.Fill(ds, "acc");

                int m = ds.Tables["acc"].Rows.Count;
                if (m > 0)
                {
                    String ustatus = Convert.ToString(ds.Tables["acc"].Rows[0]["ustatus"]);
                    String accstatus = Convert.ToString(ds.Tables["acc"].Rows[0]["acc_status"]);
                    if (ustatus == "Active" & accstatus == "Open")
                    {

                    }
                    else
                    {
                        lblfrmaccmsg.Text = "Account Closed or User Deactivated";
                        ttxttoacc.Text = "";
                        ttxttoacc.Enabled = false;
                        ttxtfrmacc.Enabled = false;
                        ttxtamt.Enabled = false;
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        
        //reset code at transfer amount tab
        protected void btntransreset_Click(object sender, EventArgs e)
        {
            lblfrmaccmsg.Text = "";
            lbltoaccmsg.Text = "";
            ttxttoacc.Text = "";
            ttxttoacc.Enabled = true;
            ttxtfrmacc.Text = "";
            ttxtfrmacc.Enabled = true;
            ttxtamt.Text = "";
            ttxtamt.Enabled = true;
            Label6.Text = "";
        }
        
        
        //code for the transfer tab
        protected void btntsub_Click(object sender, EventArgs e)
        {
            int toacc, frmacc;
            String trans_ty;
            DateTime date;
            double amt;
            toacc = Convert.ToInt16(ttxttoacc.Text);
            frmacc = Convert.ToInt16(ttxtfrmacc.Text);
            trans_ty = ttxttranstyp.Text;
            DateTime dt = DateTime.Today;

            hdntransdt.Value = String.Format("{0:yyyy-MM-dd}", dt);

            amt = Convert.ToDouble(ttxtamt.Text);
            SqlConnection scon;
            SqlCommand scmd;
           
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("insert into trans_info(to_acc_no,frm_acc_no,amount,trans_type,date) values(@a,@b,@c,@d,@e);", scon);
                scmd.Parameters.AddWithValue("a", toacc);
                scmd.Parameters.AddWithValue("b", frmacc);
                scmd.Parameters.AddWithValue("c", amt);
                scmd.Parameters.AddWithValue("d", trans_ty);
                scmd.Parameters.AddWithValue("e", hdntransdt.Value);
                scmd.ExecuteNonQuery();

                scmd = new SqlCommand("update accounts set balance=balance - @a where acc_no=@b;", scon);
                scmd.Parameters.AddWithValue("a", amt);
                scmd.Parameters.AddWithValue("b", frmacc);
                scmd.ExecuteNonQuery();

                scmd = new SqlCommand("update accounts set balance=balance + @a where acc_no=@b;", scon);
                scmd.Parameters.AddWithValue("a", amt);
                scmd.Parameters.AddWithValue("b", toacc);
                scmd.ExecuteNonQuery();

                scon.Close();
                Label6.Text = "Amount transferred Successfully....!";
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        
        
        //code to pick date
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Calendar1.Visible = true;
            //GridView2.Visible = false;

        }
        
        
        //code for tab daily transaction Report
        protected void btntransrepo_Click(object sender, EventArgs e)
        {
            SqlConnection scon;
            SqlDataAdapter sda;
            SqlCommand scmd;
            DataSet ds;
            DateTime dt = Convert.ToDateTime(txttransdate.Text);
            txttransdate.Text = String.Format("{0:yyyy-MM-dd}", dt);
            scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
            scmd = new SqlCommand("select * from trans_info where date=@a;", scon);
            scmd.Parameters.AddWithValue("a", txttransdate.Text);
            sda = new SqlDataAdapter(scmd);
            ds = new DataSet();
            sda.Fill(ds, "acc");
            GridView2.DataSource = ds;
            GridView2.DataBind();
        }
        
        
        //code for calender
        protected void Calendar1_SelectionChanged1(object sender, EventArgs e)
        {
                txttransdate.Text = Calendar1.SelectedDate.ToShortDateString();
                Calendar1.Visible = false;
            
        }
    }
}