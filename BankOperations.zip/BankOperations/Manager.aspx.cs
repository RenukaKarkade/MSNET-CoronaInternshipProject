﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;

namespace BankOperations
{
    public partial class Manager : System.Web.UI.Page
    {
        int account_no;
        String uid = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            
            DateTime dt = DateTime.Today;
            txttdate.Text = String.Format("{0:yyyy-MM-dd}", dt);
            uid = Convert.ToString(Session["userid"]);
            if (uid != "na")
                Label1.Text = "Logged in as:" + uid;
            else
                Label1.Text = "Invalid Session....Please Login...!";

            if (IsPostBack)
            {
                
                getmaxaccount();
                //txtaccno.Text = Convert.ToString(account_no);
            }
        }

        public void getmaxaccount() //function for autoincrement of account number
        {
            SqlDataAdapter sda;
            DataSet ds;
            SqlConnection scon;

            scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
            scon.Open();
            sda = new SqlDataAdapter("SELECT MAX(acc_no) FROM accounts; ", scon);
            ds = new DataSet();
            sda.Fill(ds, "acc");

            if (ds.Tables["acc"].Rows.Count > 0)
            {
                account_no = Convert.ToInt32(ds.Tables["acc"].Rows[0]["Column1"]);
                int n = ++account_no;
                txtaccno.Text = Convert.ToString(n);
            }
            else
            {
                txtaccno.Text = Convert.ToString(1001);
                account_no = Convert.ToInt16(txtaccno.Text);
            }



        }

        public void Clear() //clear function for the tab Open Account
        {
            txtaccno.Text = "";
            txtbal.Text = "";
            //ddlacctyp.SelectedItem.Value = "";
           // ddlutyp.SelectedItem.Value = "";
            txtustatus.Text = "Active";
           // ddlacstatus.SelectedItem.Value = "";
            txtaccnm.Text = "";
            lbl1.Text = "";
            ddlutyp.SelectedIndex = 0;
            ddlacctyp.SelectedIndex = 0;
            ddlacstatus.SelectedIndex = 0;
            getmaxaccount();

        }

        protected void Tab2_Click(object sender, EventArgs e) //Search Account Info
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Clicked";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Initial";
                Tab7.CssClass = "Initial";
                MainView.ActiveViewIndex = 1;
            }
            
        }

        protected void Tab3_Click(object sender, EventArgs e) //Transfer Amount
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Clicked";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Initial";
                Tab7.CssClass = "Initial";
                MainView.ActiveViewIndex = 2;
            }
        }


        protected void Tab4_Click(object sender, EventArgs e) //Daily Transaction Report
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Clicked";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Initial";
                Tab7.CssClass = "Initial";
                MainView.ActiveViewIndex = 3;
            }
        }

        protected void Tab5_Click(object sender, EventArgs e) //Active/Deactive User
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Clicked";
                Tab6.CssClass = "Initial";
                Tab7.CssClass = "Initial";
                MainView.ActiveViewIndex = 4;
            }
        }

        protected void Tab6_Click(object sender, EventArgs e) // CLose Account
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Clicked";
                Tab7.CssClass = "Initial";
                MainView.ActiveViewIndex = 5;
            }
        }
        protected void Tab7_Click(object sender, EventArgs e) //Logout
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Initial";
                Tab7.CssClass = "Clicked";
                MainView.ActiveViewIndex = 6;
                Session.Abandon();
                Response.Redirect("Default.aspx");
            }
        }

        protected void Tab1_Click(object sender, EventArgs e) //Open Account
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Clicked";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Initial";
                Tab7.CssClass = "Initial";
                MainView.ActiveViewIndex = 0;
                
            }

        }

        protected void btncreateacc_Click(object sender, EventArgs e) //Code for Open Account
        {
            int acno;
            Double bal;
            String acnm, actype, utype, ustatus, acstatus;
            acno = Convert.ToInt16(txtaccno.Text);
            bal = Convert.ToDouble(txtbal.Text);
            actype = ddlacctyp.SelectedItem.Value;
            utype = ddlutyp.SelectedItem.Value;
            ustatus = txtustatus.Text;
            acstatus = ddlacstatus.SelectedItem.Value;
            acnm = txtaccnm.Text;
            //string date = System.DateTime.Today.ToString("dd/MM/yyyy");
            //date = Convert.ToDateTime(date);
            DateTime dt = DateTime.Today.Date;
            //String.Format("{0:yyyy-dd-MM}", dt);
            //String dt = DateTime.Today.ToString("yyyy/dd/MM");
            SqlDataAdapter sda;
            DataSet ds;
            SqlConnection scon;
            SqlCommand scmd;
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("exec newacc @acc_nm,@acc_type,@ctype,@balance,@ustatus,@acc_status,@open_date", scon);

                // scmd.Parameters.AddWithValue("acc_no", acno);
                scmd.Parameters.AddWithValue("acc_nm", acnm);
                scmd.Parameters.AddWithValue("acc_type", actype);
                scmd.Parameters.AddWithValue("ctype", utype);
                scmd.Parameters.AddWithValue("balance", bal);
                scmd.Parameters.AddWithValue("ustatus", ustatus);
                scmd.Parameters.AddWithValue("acc_status", acstatus);
                scmd.Parameters.AddWithValue("open_date", dt);

                int n = scmd.ExecuteNonQuery();
                if (n > 0)
                {
                    lbl1.Text = "Account opened successfully";
                    scmd = new SqlCommand("insert into users(acc_no,ustatus,acc_status,unm) values (" + txtaccno.Text + ",'" + txtustatus.Text + "','" + ddlacstatus.SelectedValue + "','" + txtaccnm.Text + "'); ", scon);
                    scmd.ExecuteNonQuery();
                    
                }
                else
                {
                    lbl1.Text = "Account Creation Failed";
                }

                scon.Close();
                

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        protected void btnclose_Click(object sender, EventArgs e) //Code for Close Account
        {
            int acno;
            String astatus, ustatus;
            acno = Convert.ToInt16(txt_accno.Text);
            astatus = ddlaccstatus.SelectedItem.Value;
            ustatus = ddlustatus.SelectedItem.Value;
            SqlDataAdapter sda;
            DataSet ds;
            SqlConnection scon;
            SqlCommand scmd;
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();
                scmd = new SqlCommand("update accounts set acc_status=@a,ustatus=@b where acc_no=@c;", scon);
                scmd.Parameters.AddWithValue("a", astatus);
                scmd.Parameters.AddWithValue("b", ustatus);
                scmd.Parameters.AddWithValue("c", acno);
                int n = scmd.ExecuteNonQuery();
                if (n > 0)
                {
                    scmd = new SqlCommand("update users set acc_status=@x, ustatus=@y where acc_no=@z;", scon);
                    scmd.Parameters.AddWithValue("x", astatus);
                    scmd.Parameters.AddWithValue("y", ustatus);
                    scmd.Parameters.AddWithValue("z", acno);
                    scmd.ExecuteNonQuery();
                    lbl3.Text = "Account Closed successfully";
                }
                else
                {
                    lbl3.Text = "Account Closed Failed";
                }
                scon.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


        }

        protected void btntransfer_Click(object sender, EventArgs e) //Code for Transfer Amount
        {
            int toacc, frmacc;
            String trans_ty;
           
            double amt;
            toacc = Convert.ToInt16(txttoacc.Text);
            frmacc = Convert.ToInt16(txtfrmacc.Text);
            trans_ty = txttranstype.Text;
            amt = Convert.ToDouble(txtamt.Text);
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("insert into trans_info(to_acc_no,frm_acc_no,amount,trans_type,date) values(@a,@b,@c,@d,@e);", scon);
                scmd.Parameters.AddWithValue("a", toacc);
                scmd.Parameters.AddWithValue("b", frmacc);
                scmd.Parameters.AddWithValue("c", amt);
                scmd.Parameters.AddWithValue("d", trans_ty);
                scmd.Parameters.AddWithValue("e", txttdate.Text);
                scmd.ExecuteNonQuery();

                scmd = new SqlCommand("update accounts set balance=balance - @a where acc_no=@b;", scon);
                scmd.Parameters.AddWithValue("a", amt);
                scmd.Parameters.AddWithValue("b", frmacc);
                scmd.ExecuteNonQuery();

                scmd = new SqlCommand("update accounts set balance=balance + @a where acc_no=@b;", scon);
                scmd.Parameters.AddWithValue("a", amt);
                scmd.Parameters.AddWithValue("b", toacc);
                scmd.ExecuteNonQuery();

                lbltransmsg.Text = "Amount Transfer Successfully.....!";
                scon.Close();
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //Textbox Code at transfer amount to ckeck wheather Account is open or close
        protected void txttoacc_TextChanged1(object sender, EventArgs e)  {
            int toacc;
            toacc = Convert.ToInt16(txttoacc.Text);
            lbltoaccmsg.Text = "";
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("SELECT ustatus,acc_status FROM accounts where acc_no=@a; ", scon);
                scmd.Parameters.AddWithValue("a", toacc);

                sda = new SqlDataAdapter(scmd);
                ds = new DataSet();
                sda.Fill(ds, "acc");

                int m = ds.Tables["acc"].Rows.Count;
                if (m > 0)
                {
                    String ustatus = Convert.ToString(ds.Tables["acc"].Rows[0]["ustatus"]);
                    String accstatus = Convert.ToString(ds.Tables["acc"].Rows[0]["acc_status"]);
                    if (ustatus == "Active" & accstatus == "Open")
                    {

                    }
                    else
                    {
                        lbltoaccmsg.Text = "Account Closed or User Deactivated";
                        txttoacc.Text = "";
                        txttoacc.Focus();
                        txttoacc.Enabled = false;
                        txtfrmacc.Enabled = false;
                        txttranstype.Enabled = false;
                        txttdate.Enabled = false;
                        txtamt.Enabled = false;
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Textbox Code at transfer amount to ckeck wheather Account is open or close
        protected void txtfrmacc_TextChanged(object sender, EventArgs e)
        {
            int frmacc;
            lblfrmaccmsg.Text = "";
            frmacc = Convert.ToInt16(txtfrmacc.Text);
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("SELECT ustatus,acc_status FROM accounts where acc_no=@b; ", scon);
                scmd.Parameters.AddWithValue("b", frmacc);

                sda = new SqlDataAdapter(scmd);
                ds = new DataSet();
                sda.Fill(ds, "acc");

                int m = ds.Tables["acc"].Rows.Count;
                if (m > 0)
                {
                    String ustatus = Convert.ToString(ds.Tables["acc"].Rows[0]["ustatus"]);
                    String accstatus = Convert.ToString(ds.Tables["acc"].Rows[0]["acc_status"]);
                    if (ustatus == "Active" & accstatus == "Open")
                    {

                    }
                    else
                    {
                        lblfrmaccmsg.Text = "Account CLosed or User Deactivated";
                        txtfrmacc.Text = "";
                        txtfrmacc.Focus();
                        txttoacc.Enabled = false;
                        txtfrmacc.Enabled = false;
                        txttranstype.Enabled = false;
                        txttdate.Enabled = false;
                        txtamt.Enabled = false;
                        return;

                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        //Reset button Code at transfer amount 
        protected void btnreset_Click(object sender, EventArgs e)
        {
            txttoacc.Enabled = true;
            txttoacc.Text = "";
            txtfrmacc.Enabled = true;
            txtfrmacc.Text = "";
            txttranstype.Enabled = true;
            txttdate.Enabled = true;
            txtamt.Enabled = true;
            txtamt.Text = "";
            lblfrmaccmsg.Text = "";
            lbltoaccmsg.Text = "";
            lbltransmsg.Text = "";
        }

        protected void LinkButton1_Click(object sender, EventArgs e)// Code to pick date
        {
            Calendar1.Visible = true;
            // Panel1.Visible = true;
            //GridView2.Visible = false;
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e) //code for calender
        {
            txttransdate.Text = Calendar1.SelectedDate.ToShortDateString();
            // Panel1.Visible = true;

            Calendar1.Visible = false;
        }

        protected void btntransrepo_Click(object sender, EventArgs e)// code of Daily Transaction Report
        {
            SqlConnection scon;
            SqlDataAdapter sda;
            SqlCommand scmd;
            DataSet ds;
            //string vFDate;
            //vFDate = Convert.ToDateTime(txttransdate.Text).ToShortDateString();
            //vFDate.ToString("yyyy-MM-dd");
            // DateTime dt = Convert.ToDateTime(txttransdate.Text);
            //txttransdate.Text = String.Format("{0:yyyy-dd-MM}", dt);
           
            scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
            scmd = new SqlCommand("select * from trans_info where date=@a;", scon);
            scmd.Parameters.AddWithValue("a", txttransdate.Text);
            sda = new SqlDataAdapter(scmd);
            ds = new DataSet();
            sda.Fill(ds, "acc");
            GridView2.DataSource = ds;
            GridView2.DataBind();
        }

        protected void btnsubmit_Click(object sender, EventArgs e) //Code for Search Account Info.
        {
            SqlConnection scon;
            SqlDataAdapter sda;
            SqlCommand scmd;
            DataSet ds;

            scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
            scmd = new SqlCommand("select * from accounts where acc_no=@a;", scon);
            scmd.Parameters.AddWithValue("a", stxtaccno.Text);
            sda = new SqlDataAdapter(scmd);
            ds = new DataSet();
            sda.Fill(ds, "acc");
            GridView3.DataSource = ds;
            GridView3.DataBind();
        }

        protected void btnaccreset_Click(object sender, EventArgs e)
        {
            Clear();
        }
    }
}
