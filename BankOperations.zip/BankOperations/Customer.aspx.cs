﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace BankOperations
{
    
    public partial class Customer : System.Web.UI.Page
    {
        String uid = "", pass, cpsw;
        protected void Page_Load(object sender, EventArgs e)
        {

            uid = Convert.ToString(Session["userid"]);
            if (uid != "na")
                Label1.Text = "Logged in as:" + uid;
            else
                Label1.Text = "Invalid Session....Please Login...!";

            if (!Page.IsPostBack)
            {
                FillDropDown();
            }

        }

        protected void Tab1_Click(object sender, EventArgs e)//Tab Account Statement
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {

                Tab1.CssClass = "Clicked";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Initial";
                MainView.ActiveViewIndex = 0;
                SqlConnection scon;
                SqlCommand scmd;
                SqlDataAdapter sda;
                DataSet ds;
                try
                {
                    scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                    scon.Open();

                    scmd = new SqlCommand("SELECT * FROM trans_info where frm_acc_no=@a or to_acc_no=@b; ", scon);
                    scmd.Parameters.AddWithValue("a", uid);
                    scmd.Parameters.AddWithValue("b", uid);
                    sda = new SqlDataAdapter(scmd);
                    ds = new DataSet();
                    sda.Fill(ds, "acc");
                    GridView1.DataSource = ds;
                    GridView1.DataBind();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        protected void Tab2_Click(object sender, EventArgs e)//Tab Transfer Amount
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Clicked";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Initial";
                MainView.ActiveViewIndex = 1;
            }
        }

        protected void Tab3_Click(object sender, EventArgs e)//Tab Pay Electric Bill
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Clicked";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Initial";
                MainView.ActiveViewIndex = 2;
            }
        }

        protected void Tab4_Click(object sender, EventArgs e)//Tab Recharge
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Clicked";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Initial";
                MainView.ActiveViewIndex = 3;
            }

        }

        protected void Tab5_Click(object sender, EventArgs e)//Change Password
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Clicked";
                Tab6.CssClass = "Initial";
                MainView.ActiveViewIndex = 4;
            }
        }

        protected void Tab6_Click(object sender, EventArgs e)//Tab Logout
        {
            if (uid == "na")
            {
                Session.Abandon();
            }
            else
            {
                Tab1.CssClass = "Initial";
                Tab2.CssClass = "Initial";
                Tab3.CssClass = "Initial";
                Tab4.CssClass = "Initial";
                Tab5.CssClass = "Initial";
                Tab6.CssClass = "Clicked";
                MainView.ActiveViewIndex = 5;
                Session.Abandon();
                Response.Redirect("Default.aspx");
            }

        }
        //code for textbox to check whether account is open or closed
        protected void ttxttoacc_TextChanged(object sender, EventArgs e)
        {
            int toacc;
            toacc = Convert.ToInt16(ttxttoacc.Text);
            lbltoaccno.Text = "";
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("SELECT ustatus,acc_status FROM accounts where acc_no=@a; ", scon);
                scmd.Parameters.AddWithValue("a", toacc);

                sda = new SqlDataAdapter(scmd);
                ds = new DataSet();
                sda.Fill(ds, "acc");

                int m = ds.Tables["acc"].Rows.Count;
                if (m > 0)
                {
                    String ustatus = Convert.ToString(ds.Tables["acc"].Rows[0]["ustatus"]);
                    String accstatus = Convert.ToString(ds.Tables["acc"].Rows[0]["acc_status"]);
                    if (ustatus == "Active" & accstatus == "Open")
                    {

                    }
                    else
                    {
                        lbltoaccno.Text = "Account Closed or User Deactivated";
                        ttxttoacc.Text = "";
                        ttxttoacc.Enabled = false;
                        ttxtfrmacc.Enabled = false;
                        ttxtamt.Enabled = false;
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        //code for textbox to check whether account is open or closed
        protected void ttxtfrmacc_TextChanged(object sender, EventArgs e)
        {
            int frmacc;
            frmacc = Convert.ToInt16(ttxtfrmacc.Text);
            lblfrmaccno.Text = "";
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("SELECT ustatus,acc_status FROM accounts where acc_no=@a; ", scon);
                scmd.Parameters.AddWithValue("a", frmacc);

                sda = new SqlDataAdapter(scmd);
                ds = new DataSet();
                sda.Fill(ds, "acc");

                int m = ds.Tables["acc"].Rows.Count;
                if (m > 0)
                {
                    String ustatus = Convert.ToString(ds.Tables["acc"].Rows[0]["ustatus"]);
                    String accstatus = Convert.ToString(ds.Tables["acc"].Rows[0]["acc_status"]);
                    if (ustatus == "Active" & accstatus == "Open")
                    {

                    }
                    else
                    {
                        lblfrmaccno.Text = "Account Closed or User Deactivated";
                        ttxttoacc.Text = "";
                        ttxttoacc.Enabled = false;
                        ttxtfrmacc.Enabled = false;
                        ttxtamt.Enabled = false;
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //code to reset transfer tab
        protected void transreset_Click(object sender, EventArgs e)
        {
            lbltoaccno.Text = "";
            lblfrmaccno.Text = "";
            ttxttoacc.Text = "";
            ttxttoacc.Enabled = true;
            ttxtfrmacc.Text = "";
            ttxtfrmacc.Enabled = true;
            ttxtamt.Text = "";
            ttxtamt.Enabled = true;
            Label2.Text = "";
        }
        //code to transfer Amount
        protected void btntsub_Click(object sender, EventArgs e)
        {

            int toacc, frmacc;
            String trans_ty;
            double amt;
            toacc = Convert.ToInt16(ttxttoacc.Text);
            frmacc = Convert.ToInt16(ttxtfrmacc.Text);
            trans_ty = ttxttranstyp.Text;
            DateTime dt = DateTime.Today;

            hdntransdt.Value = String.Format("{0:yyyy-MM-dd}", dt);

            amt = Convert.ToDouble(ttxtamt.Text);
            SqlConnection scon;
            SqlCommand scmd;

            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("insert into trans_info(to_acc_no,frm_acc_no,amount,trans_type,date) values(@a,@b,@c,@d,@e);", scon);
                scmd.Parameters.AddWithValue("a", toacc);
                scmd.Parameters.AddWithValue("b", frmacc);
                scmd.Parameters.AddWithValue("c", amt);
                scmd.Parameters.AddWithValue("d", trans_ty);
                scmd.Parameters.AddWithValue("e", hdntransdt.Value);
                scmd.ExecuteNonQuery();

                scmd = new SqlCommand("update accounts set balance=balance - @a where acc_no=@b;", scon);
                scmd.Parameters.AddWithValue("a", amt);
                scmd.Parameters.AddWithValue("b", frmacc);
                scmd.ExecuteNonQuery();

                scmd = new SqlCommand("update accounts set balance=balance + @a where acc_no=@b;", scon);
                scmd.Parameters.AddWithValue("a", amt);
                scmd.Parameters.AddWithValue("b", toacc);
                scmd.ExecuteNonQuery();

                scon.Close();
                Label2.Text = "Amount Transfered Successfully...!";
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //code for reset button
        protected void btnpasreset_Click(object sender, EventArgs e)
        {
            lblcpass.Text = "";
            txtnwpsw.Text = "";
            txtcnfpsw.Text = "";
            txtnwpsw.Enabled = true;
            txtcnfpsw.Enabled = true;
            txtcurpsw.Enabled = true;
            CompareValidator1.Text = "";
            lblpasschng.Text = "";
        }
        //code to call company list dynamically 
        void FillDropDown()
        {
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
            scon.Open();
            scmd = new SqlCommand("select acc_nm from accounts where ctype='Company' and ustatus='Active' and acc_status='Open';", scon);
            sda = new SqlDataAdapter(scmd);
            ds = new DataSet();
            sda.Fill(ds, "acc");
            ddlrcompany.DataTextField = ds.Tables[0].Columns["acc_nm"].ToString();
            ddlecomp.DataTextField = ds.Tables[0].Columns["acc_nm"].ToString();
            //Label2.Text = ds.Tables[0].Columns["acc_no"].ToString();
            ddlrcompany.DataSource = ds.Tables[0];
            ddlrcompany.DataBind();
            ddlecomp.DataSource = ds.Tables[0];
            ddlecomp.DataBind();
        }
        //code to dynamically call company list
        protected void ddlrcompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            int accno = ' ';
            //lblcomp.Text = ddlrcompany.SelectedItem.Value;

            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
            scon.Open();
            scmd = new SqlCommand("select acc_no from accounts where acc_nm=@b;", scon);
            scmd.Parameters.AddWithValue("b", ddlrcompany.SelectedItem.Value);
            sda = new SqlDataAdapter(scmd);
            ds = new DataSet();
            sda.Fill(ds, "acc");
            int m = ds.Tables["acc"].Rows.Count;
            if (m > 0)
            {
                accno = Convert.ToInt16(ds.Tables["acc"].Rows[0]["acc_no"]);
            }
            txtrtoacc.Text = Convert.ToString(accno);
            txtrfrmaccno.Text = uid;


        }
        //code of reset button
        protected void btnrrst_Click(object sender, EventArgs e)
        {
            lblrech.Text = "";
            txtramt.Text = "";
            txtrfrmaccno.Text = "";
            txtrtoacc.Text = "";
            ddlrcompany.DataBind();
        }
        //code to recharge
        protected void btnrecharge_Click(object sender, EventArgs e)
        {
            int toacc, frmacc;
            String trans_ty;
            
            double amt;
            toacc = Convert.ToInt16(txtrtoacc.Text);
            frmacc = Convert.ToInt16(txtrfrmaccno.Text);
            trans_ty = txtrtransty.Text;
            DateTime dt = DateTime.Today;
            hdnrdt.Value = String.Format("{0:yyyy-MM-dd}", dt);

            amt = Convert.ToDouble(txtramt.Text);
            SqlConnection scon;
            SqlCommand scmd;

            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("insert into trans_info(to_acc_no,frm_acc_no,amount,trans_type,date) values(@a,@b,@c,@d,@e);", scon);
                scmd.Parameters.AddWithValue("a", toacc);
                scmd.Parameters.AddWithValue("b", frmacc);
                scmd.Parameters.AddWithValue("c", amt);
                scmd.Parameters.AddWithValue("d", trans_ty);
                scmd.Parameters.AddWithValue("e", hdnrdt.Value);
                scmd.ExecuteNonQuery();

                scmd = new SqlCommand("update accounts set balance=balance - @a where acc_no=@b;", scon);
                scmd.Parameters.AddWithValue("a", amt);
                scmd.Parameters.AddWithValue("b", frmacc);
                scmd.ExecuteNonQuery();

                scmd = new SqlCommand("update accounts set balance=balance + @a where acc_no=@b;", scon);
                scmd.Parameters.AddWithValue("a", amt);
                scmd.Parameters.AddWithValue("b", toacc);
                scmd.ExecuteNonQuery();
                scon.Close();
                lblrech.Text = "Recharge Successful";
                
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //code to dynamically call company list
        protected void ddlecomp_SelectedIndexChanged(object sender, EventArgs e)
        {
            int accno = ' ';
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;
            scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
            scon.Open();
            scmd = new SqlCommand("select acc_no from accounts where acc_nm=@b;", scon);
            scmd.Parameters.AddWithValue("b", ddlecomp.SelectedItem.Value);
            sda = new SqlDataAdapter(scmd);
            ds = new DataSet();
            sda.Fill(ds, "acc");
            int m = ds.Tables["acc"].Rows.Count;
            if (m > 0)
            {
                accno = Convert.ToInt16(ds.Tables["acc"].Rows[0]["acc_no"]);
            }
            txtetoacc.Text = Convert.ToString(accno);
            txtefrmaccno.Text = uid;


        }
        //code to paybill
        protected void btnpayebill_Click(object sender, EventArgs e)
        {
            int toacc, frmacc;
            String trans_ty;

            double amt;
            toacc = Convert.ToInt16(txtetoacc.Text);
            frmacc = Convert.ToInt16(txtefrmaccno.Text);
            trans_ty = txtedepo.Text;
            DateTime dt = DateTime.Today;
            hdnecomp.Value = String.Format("{0:yyyy-MM-dd}", dt);

            amt = Convert.ToDouble(txteamt.Text);
            SqlConnection scon;
            SqlCommand scmd;

            try
            {
                scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                scon.Open();

                scmd = new SqlCommand("insert into trans_info(to_acc_no,frm_acc_no,amount,trans_type,date) values(@a,@b,@c,@d,@e);", scon);
                scmd.Parameters.AddWithValue("a", toacc);
                scmd.Parameters.AddWithValue("b", frmacc);
                scmd.Parameters.AddWithValue("c", amt);
                scmd.Parameters.AddWithValue("d", trans_ty);
                scmd.Parameters.AddWithValue("e", hdnecomp.Value);
                scmd.ExecuteNonQuery();

                scmd = new SqlCommand("update accounts set balance=balance - @a where acc_no=@b;", scon);
                scmd.Parameters.AddWithValue("a", amt);
                scmd.Parameters.AddWithValue("b", frmacc);
                scmd.ExecuteNonQuery();

                scmd = new SqlCommand("update accounts set balance=balance + @a where acc_no=@b;", scon);
                scmd.Parameters.AddWithValue("a", amt);
                scmd.Parameters.AddWithValue("b", toacc);
                scmd.ExecuteNonQuery();
                scon.Close();
                lblpaybill.Text = "Bill Paid Successfully";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        //code to reset pay bill tab
        protected void btnpayreset_Click(object sender, EventArgs e)
        {
            lblpaybill.Text = "";
            txteamt.Text = "";
            txtefrmaccno.Text = "";
            txtetoacc.Text = "";
            ddlecomp.DataBind();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;

            scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
            scon.Open();
            scmd = new SqlCommand("select balance from accounts where acc_no=@a;", scon);
            scmd.Parameters.AddWithValue("a", uid);

            sda = new SqlDataAdapter(scmd);
            ds = new DataSet();
            sda.Fill(ds, "acc");

            int m = ds.Tables["acc"].Rows.Count;
            if (m > 0)
            {
                
                Label3.Text = Convert.ToString(ds.Tables["acc"].Rows[0][0]);
            }
        }

        //code to change password
        protected void btnchngpsw_Click(object sender, EventArgs e)
        {
            String npsw, cnfpsw;
            
            SqlConnection scon;
            SqlCommand scmd;
            
            cpsw = txtcurpsw.Text;
            npsw = txtnwpsw.Text;
            cnfpsw = txtcnfpsw.Text;

            try
            {
                
                if (npsw.Equals(cnfpsw))
                {
                        scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
                        scon.Open();
                        scmd =new SqlCommand("update users set psw=  '" + npsw + "' where acc_no='" + uid + "';",scon);
                        scmd.ExecuteNonQuery();
		                lblpasschng.Text=" Password is updated";
                    }
                    else
                    {
                        lblpasschng.Text="Confirm Password not matched with New Password";
                    }

               
            }
            catch (Exception ex)
            {
			Console.WriteLine(ex.Message);
            }
        }
        //textbox code at password tab
        protected void txtcurpsw_TextChanged(object sender, EventArgs e)
        {
            SqlConnection scon;
            SqlCommand scmd;
            SqlDataAdapter sda;
            DataSet ds;

            cpsw = txtcurpsw.Text;
            
            scon = new SqlConnection("server=DESKTOP-QUCCIJI\\SQLEXPRESS;uid=sa;pwd=microsoft;database=bankingdb");
            scon.Open();
            scmd = new SqlCommand("select psw from users  where acc_no=@a;",scon);
            scmd.Parameters.AddWithValue("a", uid);
            sda = new SqlDataAdapter(scmd);
            ds = new DataSet();
            sda.Fill(ds, "acc");
            int m = ds.Tables["acc"].Rows.Count;
            if (m > 0)
            {
                pass = Convert.ToString(ds.Tables["acc"].Rows[0]["psw"]);
                if(pass.Equals(cpsw))                {

                }
                else
                {
                    lblcpass.Text = "Current Password is Incorrect";
                    txtnwpsw.Enabled=false;
                    txtcnfpsw.Enabled = false;
                    txtcurpsw.Enabled = false;
                }
            }
        }
    }
}